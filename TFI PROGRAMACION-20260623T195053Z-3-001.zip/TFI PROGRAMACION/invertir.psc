Algoritmo invertir
    Definir frase, fraseInvertida, letra Como Cadena
    Definir i, largo Como Entero
    
    Escribir "Ingresa una cadena de texto o frase:"
    Leer frase
    
    largo <- Longitud(frase)
    fraseInvertida <- "" // Inicializamos la cadena vac�a
    
    // Recorremos desde la �ltima posici�n hasta la primera (posici�n 1)
    Para i <- largo Hasta 1 Con Paso -1 Hacer
        letra <- Subcadena(frase, i, i) // Tomamos la letra de la posici�n i
        fraseInvertida <- fraseInvertida + letra // La vamos pegando
    FinPara
    
    Escribir "La frase invertida es: ", fraseInvertida
FinAlgoritmo