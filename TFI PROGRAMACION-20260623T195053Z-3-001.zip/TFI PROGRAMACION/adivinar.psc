Algoritmo AdivinarNumero
    Definir numsecreto, intento, diferencia Como Entero
    
    numsecreto <- Azar(25) + 1 
    
    Escribir "Adivina un numero entre el 1 y el 25"
       
    Repetir
        Escribir "Ingresa tu n�mero: "
        Leer intento
        
        Si intento = numsecreto Entonces
            Escribir "�Correcto! Has adivinado el n�mero."
        Sino
            diferencia <- Abs(numsecreto - intento)
            
            Si diferencia <= 3 Entonces
                Escribir "Est�s cerca"
            Sino
                Escribir "Est�s alejado"
            FinSi
        FinSi
        
    Hasta Que intento = numsecreto
    
FinAlgoritmo