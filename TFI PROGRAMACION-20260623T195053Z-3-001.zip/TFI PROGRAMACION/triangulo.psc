Algoritmo triangulo
	
	definir base, altura, area Como real
	
	Escribir "Ingrese la medida de la base del triangulo en centimetros: "
	leer base
	
	Escribir "Ingrese la altura de la base del triangulo en centimetros: "
	leer altura
	
	area <- (base * altura)
	
	escribir " "
	escribir "El �rea total del triangulo es de ", area," centimetros."
	
FinAlgoritmo
