Algoritmo promedio
    definir num Como Real
	definir suma Como Real
	definir contador Como Real
	definir promedioo Como Real
    
    suma <- 0
    contador <- 0
    num <- 0
    
    Mientras num >= 0 Y contador < 10 Hacer
        Escribir "Ingrese un n�mero: "
        Leer num
	
        Si num >= 0 Entonces
            suma <- suma + num
            contador <- contador + 1
        FinSi
    FinMientras
	
	promedioo <-(suma / contador)
	
    Si contador > 0 Entonces
        Escribir "El promedio de los n�meros ingresados es: ", promedioo
    Sino
        Escribir "No se ingresaron n�meros v�lidos para calcular el promedio."
    FinSi
FinAlgoritmo