Algoritmo eje1
	
	definir palabra como cadena
	definir letra Como Caracter
	definir totalvocales, i Como Entero
	
	totalvocales <- 0
	
	escribir "Ingrese una palabra o frase: "
	leer palabra
	
	palabra<- Minusculas(palabra)
	
	Para i <- 1 Hasta longitud(palabra) Con Paso 1 Hacer
        letra <- Subcadena(palabra, i, i)
		
		si letra = "a"  o letra = "e" o letra = "i" o letra = "o" o letra = "u" Entonces
			totalvocales <- totalvocales + 1
		FinSi
	FinPara
	
	Escribir "El total de vocales es: ", totalvocales

FinAlgoritmo
	