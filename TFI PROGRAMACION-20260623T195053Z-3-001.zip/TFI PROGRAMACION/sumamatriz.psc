Algoritmo eje3
	
	definir matrizA Como Entero
	definir matrizB Como Entero
	definir matrizsuma Como Entero
	definir num, i, j Como Entero
	
	
	dimension matrizA[2, 2]
	dimension matrizB[2, 2]
	dimension matrizsuma[2, 2]
	

	Para i <- 1 Hasta 2 Con Paso 1 Hacer
        Para j <- 1 Hasta 2 Con Paso 1 Hacer
            Escribir "Matriz B - Ingresa alg�n n�mero para la matriz A: "
            Leer num
            matrizA[i, j] <- num
        FinPara
    FinPara
	
	Para i <- 1 Hasta 2 Con Paso 1 Hacer
        Para j <- 1 Hasta 2 Con Paso 1 Hacer
            Escribir "Matriz B - Ingresa alg�n n�mero para la matriz B: "
            Leer num
            matrizB[i, j] <- num
        FinPara
    FinPara
	
	Para i <- 1 Hasta 2 Con Paso 1 Hacer
        Para j <- 1 Hasta 2 Con Paso 1 Hacer
            matrizsuma[i, j] <- (matrizA[i, j] + matrizB[i, j])
        FinPara
    FinPara
	
	Escribir "La suma de matriz A y matriz B: "
	
	Para i <- 1 Hasta 2 Con Paso 1 Hacer
		Para j <- 1 Hasta 2 Con Paso 1 Hacer
			Escribir matrizsuma[i, j], " " Sin Saltar
		FinPara
		
		Escribir "" 
	FinPara
	
	
FinAlgoritmo
