Algoritmo tabla_de_multiplicar
	
	definir num, i, resultadotabla como entero
	resultadotabla <- 0
	
	escribir "Ingrese el n�mero del cual desea saber su tabla de multiplicaci�n del 1 al 20: "
	leer num
	
	Escribir "TABLA DEL ", num ":"
	Para i<-1 Hasta 20 Con Paso 1 Hacer
		resultadotabla <- (num * i)
		
		Escribir num "x", i "=", resultadotabla 
	Fin Para
	
FinAlgoritmo

