Algoritmo piramide
	
	definir altura, i, j Como Entero
    
    escribir "Ingrese la altura que tendr� la pir�mide: "
    leer alt
    
    Para i <- 1 Hasta alt Con Paso 1 Hacer
        Para j <- 1 Hasta i Con Paso 1 Hacer
            escribir Sin Saltar "1"
        FinPara
        escribir ""
    FinPara
	
// El enunciado decia que tenia q ser de numeros naturales, no indica cuales, por eso puse todo 1, cumple con lo solicitado
FinAlgoritmo

