Algoritmo interes_simple
	definir capital, tasa, tiempo, interes Como Real
	
	tasa <- (0.20) //puse 0.20 porque busqu� y no hay un porcentaje fijo.
	
	escribir "EL VALOR DE LA TASA DE INTER�S SIMPLE ES DEL 20%"
	
	escribir "Ingrese el valor del capital en pesos argentinos: "
	leer capital
	
	escribir "Ingrese el tiempo en meses: "
	leer tiempo
	
	interes <- (capital*tiempo*tasa)
	
	Escribir "El interes es de ", interes
	
	
FinAlgoritmo
